# Learning VM

This module is used to configure and setup the Learning VM.

Contact
-------

eduteam@puppet.com
